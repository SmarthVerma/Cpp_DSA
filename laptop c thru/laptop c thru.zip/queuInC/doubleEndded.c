#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>

typedef struct Node{
    int data;
    struct Node* next;
    struct Node* prev;
}Node;

typedef struct Dqueue{
    Node* front;
    Node* rear;
    int size;
}Dqueue;

void initialize(Dqueue* q){
    q->front=NULL;
    q->rear=NULL;
    q->size=0;
}

bool isEmpty(Dqueue* q){
    return q->size==0;
}

void insertFront(Dqueue* q, int val){

    Node* newNode= (Node*) malloc(sizeof(Node));
    if(newNode==NULL){
        printf("Failed to allocate");
        return;
    }

    newNode->data=val;
    newNode->prev=NULL;
    newNode->next=q->front;


    q->size++;
    if(isEmpty(q)){
        q->rear=newNode
    }else{

    }-+
    q->front=newNode;


}

